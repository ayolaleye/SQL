# SQL
Showing offf my understanding of joins
